package com.institutoi3.indra_turorias.backend_tienda;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BackendTiendaApplicationTests {

	@Test
	void contextLoads() {
	}

}
