package com.institutoi3.indra_turorias.backend_tienda;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BackendTiendaApplication {

	public static void main(String[] args) {
		SpringApplication.run(BackendTiendaApplication.class, args);
	}

}
